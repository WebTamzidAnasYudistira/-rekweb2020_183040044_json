let mahasiswa = {
    nama : "Tamzid Anas Yudistira",
    nrp : "183040055",
    email : "yudistira.183040041@unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));